<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20211216151948 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE animation MODIFY animation_id INT NOT NULL');
        $this->addSql('ALTER TABLE animation DROP PRIMARY KEY');
        $this->addSql('ALTER TABLE animation CHANGE Coord_X coord_x NUMERIC(10, 5) NOT NULL, CHANGE Coord_Y coord_y NUMERIC(10, 5) NOT NULL, CHANGE animation_titre animation_titre VARCHAR(255) NOT NULL, CHANGE animation_lieu animation_lieu VARCHAR(255) NOT NULL, CHANGE animation_photo animation_photo VARCHAR(255) NOT NULL, CHANGE animation_description animation_description VARCHAR(255) NOT NULL, CHANGE animation_id id INT AUTO_INCREMENT NOT NULL');
        $this->addSql('ALTER TABLE animation ADD PRIMARY KEY (id)');
        $this->addSql('ALTER TABLE parcours ADD id INT AUTO_INCREMENT NOT NULL, DROP PRIMARY KEY, ADD PRIMARY KEY (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE animation MODIFY id INT NOT NULL');
        $this->addSql('ALTER TABLE animation DROP PRIMARY KEY');
        $this->addSql('ALTER TABLE animation CHANGE coord_x Coord_X DOUBLE PRECISION NOT NULL, CHANGE coord_y Coord_Y DOUBLE PRECISION NOT NULL, CHANGE animation_titre animation_titre VARCHAR(100) CHARACTER SET utf8 NOT NULL COLLATE `utf8_general_ci`, CHANGE animation_lieu animation_lieu VARCHAR(100) CHARACTER SET utf8 NOT NULL COLLATE `utf8_general_ci`, CHANGE animation_photo animation_photo VARCHAR(100) CHARACTER SET utf8 NOT NULL COLLATE `utf8_general_ci`, CHANGE animation_description animation_description TEXT CHARACTER SET utf8 NOT NULL COLLATE `utf8_general_ci`, CHANGE id animation_id INT AUTO_INCREMENT NOT NULL');
        $this->addSql('ALTER TABLE animation ADD PRIMARY KEY (animation_id)');
        $this->addSql('ALTER TABLE parcours MODIFY id INT NOT NULL');
        $this->addSql('ALTER TABLE parcours DROP PRIMARY KEY');
        $this->addSql('ALTER TABLE parcours DROP id');
        $this->addSql('ALTER TABLE parcours ADD PRIMARY KEY (num_ordre)');
    }
}
