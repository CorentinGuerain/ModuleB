<?php

namespace ContainerPzeK4so;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder1d60c = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializered08d = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties56bb4 = [
        
    ];

    public function getConnection()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getConnection', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getMetadataFactory', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getExpressionBuilder', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'beginTransaction', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->beginTransaction();
    }

    public function getCache()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getCache', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getCache();
    }

    public function transactional($func)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'transactional', array('func' => $func), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'wrapInTransaction', array('func' => $func), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'commit', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->commit();
    }

    public function rollback()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'rollback', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getClassMetadata', array('className' => $className), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'createQuery', array('dql' => $dql), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'createNamedQuery', array('name' => $name), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'createQueryBuilder', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'flush', array('entity' => $entity), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'clear', array('entityName' => $entityName), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->clear($entityName);
    }

    public function close()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'close', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->close();
    }

    public function persist($entity)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'persist', array('entity' => $entity), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'remove', array('entity' => $entity), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'refresh', array('entity' => $entity), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'detach', array('entity' => $entity), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'merge', array('entity' => $entity), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getRepository', array('entityName' => $entityName), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'contains', array('entity' => $entity), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getEventManager', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getConfiguration', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'isOpen', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getUnitOfWork', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getProxyFactory', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'initializeObject', array('obj' => $obj), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'getFilters', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'isFiltersStateClean', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'hasFilters', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return $this->valueHolder1d60c->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializered08d = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder1d60c) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder1d60c = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder1d60c->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, '__get', ['name' => $name], $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        if (isset(self::$publicProperties56bb4[$name])) {
            return $this->valueHolder1d60c->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1d60c;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder1d60c;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, '__set', array('name' => $name, 'value' => $value), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1d60c;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder1d60c;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, '__isset', array('name' => $name), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1d60c;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder1d60c;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, '__unset', array('name' => $name), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder1d60c;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder1d60c;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, '__clone', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        $this->valueHolder1d60c = clone $this->valueHolder1d60c;
    }

    public function __sleep()
    {
        $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, '__sleep', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;

        return array('valueHolder1d60c');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializered08d = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializered08d;
    }

    public function initializeProxy() : bool
    {
        return $this->initializered08d && ($this->initializered08d->__invoke($valueHolder1d60c, $this, 'initializeProxy', array(), $this->initializered08d) || 1) && $this->valueHolder1d60c = $valueHolder1d60c;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder1d60c;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder1d60c;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
