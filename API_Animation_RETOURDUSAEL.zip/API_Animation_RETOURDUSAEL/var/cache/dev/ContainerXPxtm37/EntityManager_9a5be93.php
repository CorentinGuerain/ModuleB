<?php

namespace ContainerXPxtm37;
include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder4113b = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerf1a61 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties487a3 = [
        
    ];

    public function getConnection()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getConnection', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getMetadataFactory', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getExpressionBuilder', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'beginTransaction', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getCache', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getCache();
    }

    public function transactional($func)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'transactional', array('func' => $func), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'wrapInTransaction', array('func' => $func), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'commit', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->commit();
    }

    public function rollback()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'rollback', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getClassMetadata', array('className' => $className), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'createQuery', array('dql' => $dql), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'createNamedQuery', array('name' => $name), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'createQueryBuilder', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'flush', array('entity' => $entity), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'clear', array('entityName' => $entityName), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->clear($entityName);
    }

    public function close()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'close', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->close();
    }

    public function persist($entity)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'persist', array('entity' => $entity), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'remove', array('entity' => $entity), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'refresh', array('entity' => $entity), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'detach', array('entity' => $entity), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'merge', array('entity' => $entity), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getRepository', array('entityName' => $entityName), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'contains', array('entity' => $entity), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getEventManager', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getConfiguration', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'isOpen', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getUnitOfWork', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getProxyFactory', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'initializeObject', array('obj' => $obj), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'getFilters', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'isFiltersStateClean', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'hasFilters', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return $this->valueHolder4113b->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerf1a61 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder4113b) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder4113b = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder4113b->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, '__get', ['name' => $name], $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        if (isset(self::$publicProperties487a3[$name])) {
            return $this->valueHolder4113b->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4113b;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder4113b;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4113b;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder4113b;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, '__isset', array('name' => $name), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4113b;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder4113b;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, '__unset', array('name' => $name), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4113b;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder4113b;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, '__clone', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        $this->valueHolder4113b = clone $this->valueHolder4113b;
    }

    public function __sleep()
    {
        $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, '__sleep', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;

        return array('valueHolder4113b');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerf1a61 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerf1a61;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerf1a61 && ($this->initializerf1a61->__invoke($valueHolder4113b, $this, 'initializeProxy', array(), $this->initializerf1a61) || 1) && $this->valueHolder4113b = $valueHolder4113b;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder4113b;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder4113b;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
