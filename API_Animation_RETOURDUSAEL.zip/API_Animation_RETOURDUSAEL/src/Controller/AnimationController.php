<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Animation;
use Symfony\Component\HttpFoundation\JsonResponse;
use JMS\Serializer\SerializerInterface;
use JMS\Serializer\SerializationContext;
use \Symfony\Component\HttpFoundation\Request;

use Swagger\Annotations as SWG;
use Nelmio\ApiDocBundle\Annotations\Model;

class AnimationController extends AbstractController
{
    /**
     * @Route("/animation/{id}", name="LaJambeDuSaeL")
     * @Method({"GET"})
     */
    public function affichage(Animation $animation, SerializerInterface $serializer ) //, EntityManagerInterface $em 
    {
        $response = new JsonResponse();
        return $response->setContent(
                $serializer->serialize(
                        $animation,
                        'json')
                );
 
    }
    
    
    /**
     * @Route("/animation/list", name="AffichageAnimation")
     * @Method({"GET"})
     */
    public function liste(AnimationController $respository, SerializerInterface $serializer,Request $req ) {
        $list = $this->getDoctrine()->getRepository(Animation::class)->findAll();
        
        
        $response = new JsonResponse();
        return $response->setContent(
                $serializer->serialize($list, 'json')
                );
        
        
    }
}
