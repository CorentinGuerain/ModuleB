<?php

namespace App\Controller;

use App\Entity\Animation;
use JMS\Serializer\SerializerInterface;
use Nelmio\ApiDocBundle\Annotations\Model;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

class ParcourController extends AbstractController
{

    /**
     * @Route("/parcours/list", name="showParcours")
     * @Method({"GET"})
     */
    public function showParcours(SerializerInterface $serializer, Request $request)
    {
        $RAW_QUERY = 'SELECT `num_ordre`, `animation_titre`, `id_Animation`, `coord_x`, `coord_y` FROM `parcours`, `animation` WHERE animation.id = parcours.id_Animation; ';

        $list = $this->getDoctrine()->getRepository(Animation::class)->listAll();


        $response = new JsonResponse();

        return $response->setContent(
            $serializer->serialize(
                $list,
                'json')
        );

    }
}
