<?php

namespace App\Entity;

use App\Repository\AnimationRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=AnimationRepository::class)
 */
class Animation
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="decimal", precision=10, scale=5)
     */
    private $coord_X;

    /**
     * @ORM\Column(type="decimal", precision=10, scale=5)
     */
    private $coord_Y;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $animation_titre;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $animation_lieu;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $animation_photo;

    /**
     * @ORM\Column(type="string", length=300)
     */
    private $animation_description;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCoordX(): ?string
    {
        return $this->coord_X;
    }

    public function setCoordX(string $coord_X): self
    {
        $this->coord_X = $coord_X;

        return $this;
    }

    public function getCoordY(): ?string
    {
        return $this->coord_Y;
    }

    public function setCoordY(string $coord_Y): self
    {
        $this->coord_Y = $coord_Y;

        return $this;
    }

    public function getAnimationTitre(): ?string
    {
        return $this->animation_titre;
    }

    public function setAnimationTitre(string $animation_titre): self
    {
        $this->animation_titre = $animation_titre;

        return $this;
    }

    public function getAnimationLieu(): ?string
    {
        return $this->animation_lieu;
    }

    public function setAnimationLieu(string $animation_lieu): self
    {
        $this->animation_lieu = $animation_lieu;

        return $this;
    }

    public function getAnimationPhoto(): ?string
    {
        return $this->animation_photo;
    }

    public function setAnimationPhoto(string $animation_photo): self
    {
        $this->animation_photo = $animation_photo;

        return $this;
    }

    public function getAnimationDescription(): ?string
    {
        return $this->animation_description;
    }

    public function setAnimationDescription(string $animation_description): self
    {
        $this->animation_description = $animation_description;

        return $this;
    }
}
