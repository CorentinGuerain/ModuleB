<?php

namespace App\Entity;

use App\Repository\ParcoursRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ParcoursRepository::class)
 */
class Parcours
{

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue
     */
    private $num_ordre;

    /**
     * @ORM\Column(type="integer")
     */
    private $id_Animation;

    public function getNumOrdre(): ?int
    {
        return $this->num_ordre;
    }

    public function setNumOrdre(int $num_ordre): self
    {
        $this->num_ordre = $num_ordre;

        return $this;
    }

    public function getIdAnimation(): ?int
    {
        return $this->id_Animation;
    }

    public function setIdAnimation(int $id_Animation): self
    {
        $this->id_Animation = $id_Animation;

        return $this;
    }

}
